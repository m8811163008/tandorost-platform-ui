/// Support for doing something awesome.
///
/// More dartdocs go here.
library auth_repository;

export 'src/auth_repository_base.dart';
