/// Support for doing something awesome.
///
/// More dartdocs go here.
library food_repository;

export 'src/food_repository_base.dart';

// TODO: Export any libraries intended for clients of this package.
export 'src/mapper/domain_to_cache.dart';
