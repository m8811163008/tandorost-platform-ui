// import 'package:food_repository/food_repository.dart';

// void main() {
//   var awesome = Awesome();
//   print('awesome: ${awesome.isAwesome}');
// }
