void main() {
  final myMap = {'name': 'milad'};
  print(myMap['name']);
  print(myMap['a']);
}
