// import 'package:domain_model/domain_model.dart';
// import 'package:test/test.dart';

// void main() {
//   group('A group of tests', () {
//     final awesome = Awesome();

//     setUp(() {
//       // Additional setup goes here.
//     });

//     test('First Test', () {
//       expect(awesome.isAwesome, isTrue);
//     });
//   });
// }
