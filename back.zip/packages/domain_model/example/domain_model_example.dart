// import 'package:domain_model/domain_model.dart';

// void main() {
//   var awesome = Awesome();
//   print('awesome: ${awesome.isAwesome}');
// }
