enum DomainChartType {
  weight,
  waistCircumference,
  armCircumference,
  chestCircumference,
  thightCircumference,
  calfMuscleCircumference,
  hipCircumference,
  activityLevel,
}
