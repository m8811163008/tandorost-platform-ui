import 'package:flutter/material.dart';

class AboutCustomer extends StatelessWidget {
  const AboutCustomer({super.key});

  @override
  Widget build(BuildContext context) {
    return const Placeholder();
  }
}
