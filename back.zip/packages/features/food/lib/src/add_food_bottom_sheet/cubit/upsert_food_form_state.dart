part of 'upsert_food_form_cubit.dart';

@immutable
sealed class UpsertFoodFormState {}

final class UpsertFoodFormInitial extends UpsertFoodFormState {}
