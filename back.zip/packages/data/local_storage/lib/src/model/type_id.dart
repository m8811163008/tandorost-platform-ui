class TypeIDs {
  static const int activityLevelCM = 0;
  static const int foodCM = 1;
  static const int macroNutritionCM = 2;
  static const int profileCM = 3;
  static const int bodyCompositionCM = 4;
  static const int bioDataCM = 5;
  static const int activityLevelCMData = 6;
  static const int selectedFoodCM = 7;
  static const int unitOfMeasurmentCM = 8;
  static const int settingCM = 9;
  static const int changeWeightSpeed = 10;
}
