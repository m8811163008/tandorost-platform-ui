/// Support for doing something awesome.
///
/// More dartdocs go here.
library local_storage;

export 'src/local_storage.dart';
export 'src/model/model.dart';
export 'package:hive/hive.dart' show Box;
